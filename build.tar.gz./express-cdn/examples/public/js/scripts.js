
// # express-cdn-assets

var test = {
  one: {
   name: 'Object 1'
  },
  two: {
   name: 'Object 2'
  },
  three: {
   name: 'Object 3'
  }
};
