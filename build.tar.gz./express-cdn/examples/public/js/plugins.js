var plugins = function(something) {
  var test = 20, color = 0;
  for (var i=0; i<test.length; i+=1) {
    color += 1;
  }
};
